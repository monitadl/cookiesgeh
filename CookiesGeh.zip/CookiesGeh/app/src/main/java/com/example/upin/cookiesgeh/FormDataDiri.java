package com.example.upin.cookiesgeh;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class FormDataDiri extends AppCompatActivity {

    Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form_data_diri);
        btn = (Button)findViewById(R.id.btnPilihHotel);
        final EditText nama = (EditText)findViewById(R.id.editTextNama);
        final EditText alamat = (EditText)findViewById(R.id.editTextAlamat);
        final EditText notelp = (EditText)findViewById(R.id.editTextNotelp);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(TextUtils.isEmpty(nama.getText().toString())||TextUtils.isEmpty(alamat.getText().toString())
                        ||TextUtils.isEmpty(notelp.getText().toString())){
                    Toast.makeText(FormDataDiri.this, "Lengkapi data diri anda!", Toast.LENGTH_SHORT).show();
                }
                else{
                    Intent in = new Intent(getApplicationContext(),DaftarBiskuit.class);
                    in.putExtra("nama", nama.getText().toString());
                    in.putExtra("alamat", alamat.getText().toString());
                    in.putExtra("notelp", notelp.getText().toString());
                    startActivity(in);
                }
            }
        });
    }
}