package com.example.upin.cookiesgeh;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Struk extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_struk);

        Intent in = getIntent();

        String nama = in.getStringExtra("nama");
        String alamat = in.getStringExtra("alamat");
        String notelp = in.getStringExtra("notelp");
        String biskuit = in.getStringExtra("biskuit");
        String harga = in.getStringExtra("harga");

        TextView namacustomer = (TextView)findViewById(R.id.namacustomer);
        TextView alamatcustomer = (TextView)findViewById(R.id.alamatcustomer);
        TextView notelpcustomer = (TextView)findViewById(R.id.notelpcustomer);
        TextView biskuittxt = (TextView)findViewById(R.id.biskuit);
        TextView totalharga = (TextView)findViewById(R.id.totalharga);
        Button keluar = (Button)findViewById(R.id.keluar);

        namacustomer.setText(nama);
        alamatcustomer.setText(alamat);
        notelpcustomer.setText(notelp);
        biskuittxt.setText(biskuit);
        totalharga.setText(harga);

        keluar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                close();
            }
        });
    }
    public void close() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Close").setMessage("Apakah anda ingin keluar?").setCancelable(false)
                .setPositiveButton("Ya",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                moveTaskToBack(true);
                            }
                        })
                .setNegativeButton("Tidak",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        }).show();
    }
}
