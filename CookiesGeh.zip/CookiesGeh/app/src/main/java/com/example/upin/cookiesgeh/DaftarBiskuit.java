package com.example.upin.cookiesgeh;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;

public class DaftarBiskuit extends AppCompatActivity {

    Button btn;
    String biskuit="";
    int harga=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_daftar_biskuit);
        Intent in = getIntent();
        final String namacustomer = in.getStringExtra("nama");
        final String alamatcustomer = in.getStringExtra("alamat");
        final String notelpcustomer = in.getStringExtra("notelp");
        final CheckBox bisma = (CheckBox)findViewById(R.id.bisma);
        final CheckBox caromma = (CheckBox)findViewById(R.id.caromma);
        final CheckBox catemma = (CheckBox)findViewById(R.id.catemma);
        final CheckBox temma = (CheckBox)findViewById(R.id.temma);
        final CheckBox miniBisma = (CheckBox)findViewById(R.id.miniBisma);
        final CheckBox miniCaromma = (CheckBox)findViewById(R.id.miniCaromma);
        final CheckBox miniCatemma = (CheckBox)findViewById(R.id.miniCatemma);
        final CheckBox miniTemma = (CheckBox)findViewById(R.id.miniTemma);





        btn = (Button)findViewById(R.id.btnPilihHotel);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(bisma.isChecked()){
                    biskuit+="Biskuit Bisma";
                    harga+=13000;}

                if(caromma.isChecked()){
                    biskuit+="\nBiskuit Caromma";
                    harga+=13000;}

                if(catemma.isChecked()){
                    biskuit+="\nBiskuit Catemma";
                    harga+=13000;}

                if(temma.isChecked()){
                    biskuit+="\nBiskuit Temma";
                    harga+=13000;}

                if(miniBisma.isChecked()){
                    biskuit+="\nMini Biskuit Bisma";
                    harga+=5000;}

                if(miniCaromma.isChecked()){
                    biskuit+="\nMini Biskuit Caromma";
                    harga+=5000;}

                if(miniCatemma.isChecked()){
                    biskuit+="\nMini Biskuit Catemma";
                    harga+=5000;}

                if(miniTemma.isChecked()){
                    biskuit+="\nMini Biskuit Temma";
                    harga+=5000;}

                Intent i = new Intent(DaftarBiskuit.this, Struk.class);
                i.putExtra("biskuit", biskuit);
                i.putExtra("harga", Integer.toString(harga));
                i.putExtra("nama", namacustomer);
                i.putExtra("alamat", alamatcustomer);
                i.putExtra("notelp", notelpcustomer);
                startActivity(i);
            }
        });
    }
}
